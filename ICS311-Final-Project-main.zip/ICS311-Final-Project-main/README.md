# ICS311-Final-Project
This is a class project for ICS311. It is used for managing a PHP-SQL database.
